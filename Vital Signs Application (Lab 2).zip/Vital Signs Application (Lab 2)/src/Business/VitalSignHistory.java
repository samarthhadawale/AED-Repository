/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;


import java.util.ArrayList;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hp
 */
public class VitalSignHistory {
    private ArrayList<VitalSigns> vitalSignHistory;
    private Iterable<VitalSigns> vitalSignList;
    
    public VitalSignHistory()
    {
        vitalSignHistory = new ArrayList<VitalSigns>();
    }
        
         public List<VitalSigns> getAbnormalList(double maxbp, double minbp){
         List<VitalSigns> abnList = new ArrayList<>();
         
         for (VitalSigns vs : this.getVitalSignHistory())
         {
             
             if(vs.getBloodPressure()>maxbp || vs.getBloodPressure()<minbp)
             {
                 abnList.add(vs);
              
             }
         }
         return abnList;
     }

    public ArrayList<VitalSigns> getVitalSignHistory() {
        return vitalSignHistory;
    }

    public void setVitalSignHistory(ArrayList<VitalSigns> VitalSignHistory) {
        this.vitalSignHistory = VitalSignHistory;
    }
    public VitalSigns addVitals()
    {
        VitalSigns vs = new VitalSigns();
        vitalSignHistory.add (vs);
        return vs;
    }
    
    public void deleteVitals(VitalSigns V)
    {
        vitalSignHistory.remove(V);
    }
    
    
    
}
